package liu.janva;


public interface Checker 
{
	boolean checkWin(Board board, Position lastMove);
}
