package liu.janva;

import java.util.Observable;

import ChatApp.Chat;
import ChatApp.ChatCallback;


//Models user still under consideration given time
// public class User extends Observable {
public class User {

//	private String name;
//	private int team;
//	Chat chatImpl;
//	ChatCallback callback;
	public String name;
	public int team;
}
