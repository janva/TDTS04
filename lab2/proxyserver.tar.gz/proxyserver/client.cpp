#include "client.h"
#include "ResponseMessage.h"
#include <string>
#include <cstring>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <vector>
#include <sys/fcntl.h>
#include "debug.h"
#include "ContentValidator.h"

using std::cout;
using std::endl;
using std::vector;
using std::string;

// get sockaddr, IPv4 or IPv6:
void* Client::get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET)
    {
	return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

void Client::init_client ( const char* node)
{
    struct addrinfo hints;
    int rv;
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if ((rv = getaddrinfo(node , PORT,   &hints, &servinfo)) != 0) {
       	fprintf(stderr, "getaddrinfo@node:%s\n %s\n", node, gai_strerror(rv));
	exit (1);
    }
}


void Client::connect_socket ()
{
    addrinfo* p;
    char s[INET6_ADDRSTRLEN];
   
    // loop through all the results and connect to the first we can.
    for(p = servinfo; p != NULL; p = p->ai_next) {
	if ((sockfd = socket(p->ai_family, p->ai_socktype,
			     p->ai_protocol)) == -1) {
	    perror("client: socket");
	    continue;
	}
      
	if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
	    close(sockfd);
	    perror("client: connect");
	    continue;
	}

	break;
    }
   
    if (p == NULL) {
	fprintf(stderr, "client: failed to connect\n");
	exit (2);
    }
    inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
	      s, sizeof s);
    printf("client: connecting to %s\n", s);
    freeaddrinfo(servinfo); // all done with this structure
}

//3)
bool Client::is_valid(ResponseMessage respMsg)
{
    //8) filter only treats content of  text/plain or text/html
    std::string type {respMsg.get_header("Content-Type")};
    if (type == "text/plain" ||type == "text/html")
    {
	Validator validate("forbidden.txt");
	return validate(respMsg.get_entity_body());
    }
    return true; 
}
//3)
bool Client::is_valid(RequestMessage reqMsg)
{
    Validator validate("forbidden.txt");
    return validate(reqMsg.get_request_line());
}


ResponseMessage Client::forward (RequestMessage&  reqMsg) 
{
    reqMsg.set_header("Connection","Close");
    std::string reqMsgCppStr = reqMsg.to_str();
    char*  reqMsgCStr = new char[reqMsgCppStr.length ()+1];    
    strcpy (reqMsgCStr, reqMsgCppStr.c_str());
    //2.4 forwards request to server on behalf of browser to webserver
    send_message (reqMsgCStr);
    //2.6 receive messages from server
    ResponseMessage respMsg=receive_message();
    delete[]reqMsgCStr;

    //3)
    if (is_valid(respMsg) && is_valid(reqMsg))
    {
       //2.8 legal page pass back it as is.
	return respMsg;
    }
    //3) return redirection-respose  instead. brower will preform annother get to
    //   to but the redirected page instead.
    ResponseMessage redirected_resp{};
    std::string ReDirStatusLine{"HTTP/1.1 302 Found\r"};
    std::string LocHeader{"http://www.ida.liu.se/~TDTS04/labs/2011/ass2/error2.html\r"};
    redirected_resp.set_status_line(ReDirStatusLine);
    redirected_resp.set_header("Location",LocHeader);
    redirected_resp.set_message_size(120);
    //2.9 if illegal content we redirect
    return redirected_resp;
}

ResponseMessage  Client::receive_message ()
{
    int  numbytes=1;    
    vector<char> buf(MAX_SIZE);;
    vector<char> bigbuf(0);
    //2.7 receive response from webserver
    while((numbytes=recv(sockfd, &buf[0], buf.size(), 0)) >0 ){
	buf.resize(numbytes);
	bigbuf.insert(bigbuf.end(), buf.begin(), buf.end());
	buf.clear();
	buf.resize(MAX_SIZE);
    }
    //all done set upp ResponseMessage
    ResponseMessage response_message_3(bigbuf);
    return response_message_3;
}

//2.5 This sends message to server
void Client::send_message (const char* buf)
{
    int bytessent;
    if ((bytessent=send(sockfd, buf, strlen(buf), 0)) == -1)
	perror("send");
}

void Client::close_socket ()
{
    close(sockfd);
}


void Client::setup (std::string host)
{
    init_client (host.c_str ());
     connect_socket ();
}
